package com.cartService.CartService.Model;

import java.time.LocalDate;
//import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Document(collection="drugs")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Drugs {
	

	
	@Id
	private int drugsId;
	private String drugsName;
	private double drugsCost;
	private int stockQty;
	private String categories;
	private String supplierName;
	private int drugsQty;
	private LocalDate dateOfExpiration;
	private double total;
	
	
}